import { Component, OnInit } from '@angular/core';
import { Employee } from './Employee';
import { SaveEmployeeService } from '../save-employee.service';

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent implements OnInit {

  employee = new Employee('101','Ankit Sharma', 'FSD', 1200000);
  constructor(private empService : SaveEmployeeService) { }

  ngOnInit() {

  }

  onSubmit(){
   console.log(this.employee);
    this.empService.save(this.employee)
    .subscribe(
      data => console.log('Success!!!' , data),
      error => console.error('Errors!', error)
      
    )

  }

}
