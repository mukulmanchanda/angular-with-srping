package com.cts.repository;

import com.cts.entity.Employee;

public interface EmployeeDao {

	boolean persistEmployee(Employee employee);

	boolean getById(Employee employee);

}