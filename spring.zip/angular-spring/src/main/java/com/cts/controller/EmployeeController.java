package com.cts.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.entity.Employee;
import com.cts.service.EmployeeService;


@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequestMapping("/employee")
public class EmployeeController {
	
	@Autowired
	private EmployeeService empService;
	
	@PostMapping("/save")
	public String saveEmployee(@RequestBody Employee employee) {
		if(empService.saveEmployee(employee))
			return "Data recieved";
		return "something went wrong";
	}
	
	@GetMapping(value = "details")
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	public List<Employee> listOfEmployees(){
		List<Employee> emp = new ArrayList<Employee>();
		Employee e = new Employee();
		e.setEmpId("101");
		e.setEmpDesignation("FSD");
		e.setEmpName("Ankit Sharma");
		e.setEmpSalary(1200000.0);
		
		Employee e1 = new Employee();
		e1.setEmpId("102");
		e1.setEmpDesignation("FSD");
		e1.setEmpName("Ajay Sharma");
		e1.setEmpSalary(1100000.0);
		
		emp.add(e);
		emp.add(e1);
		
		return emp;
	}
	

}
